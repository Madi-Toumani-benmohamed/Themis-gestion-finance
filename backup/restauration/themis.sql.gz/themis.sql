--
-- PostgreSQL database dump
--

\restrict vJRrUIqXhVpnfG0CDmbwyhcD5BcPclmQbEvaxIH0wtAPM7bSKKMv5h8kd6n3OPp

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_snapshots; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.account_snapshots (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    snap_date date NOT NULL,
    balance numeric(12,2) NOT NULL
);


ALTER TABLE public.account_snapshots OWNER TO themis;

--
-- Name: account_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.account_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_snapshots_id_seq OWNER TO themis;

--
-- Name: account_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.account_snapshots_id_seq OWNED BY public.account_snapshots.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.accounts (
    id bigint NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'courant'::text NOT NULL,
    interest_rate numeric(5,2),
    deposit_limit numeric(12,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_id bigint
);


ALTER TABLE public.accounts OWNER TO themis;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO themis;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: analyses; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.analyses (
    id integer NOT NULL,
    month text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_id bigint
);


ALTER TABLE public.analyses OWNER TO themis;

--
-- Name: analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analyses_id_seq OWNER TO themis;

--
-- Name: analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.analyses_id_seq OWNED BY public.analyses.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.budgets (
    id bigint NOT NULL,
    monthly_limit numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    domain_id bigint,
    owner_id bigint,
    CONSTRAINT budgets_monthly_limit_check CHECK ((monthly_limit > (0)::numeric))
);


ALTER TABLE public.budgets OWNER TO themis;

--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.budgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budgets_id_seq OWNER TO themis;

--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: credits; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.credits (
    id bigint NOT NULL,
    name text NOT NULL,
    monthly_amount numeric(12,2) NOT NULL,
    months_total integer NOT NULL,
    start_month character(7) NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    owner_id bigint,
    CONSTRAINT credits_monthly_amount_check CHECK ((monthly_amount > (0)::numeric)),
    CONSTRAINT credits_months_total_check CHECK ((months_total > 0))
);


ALTER TABLE public.credits OWNER TO themis;

--
-- Name: credits_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.credits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credits_id_seq OWNER TO themis;

--
-- Name: credits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.credits_id_seq OWNED BY public.credits.id;


--
-- Name: domains; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.domains (
    id bigint NOT NULL,
    name text NOT NULL,
    parent_id bigint,
    color text DEFAULT '#66736C'::text NOT NULL,
    owner_id bigint
);


ALTER TABLE public.domains OWNER TO themis;

--
-- Name: domains_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.domains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.domains_id_seq OWNER TO themis;

--
-- Name: domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.domains_id_seq OWNED BY public.domains.id;


--
-- Name: rules; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.rules (
    id integer NOT NULL,
    pattern text NOT NULL,
    domain_id bigint NOT NULL,
    owner_id bigint
);


ALTER TABLE public.rules OWNER TO themis;

--
-- Name: rules_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rules_id_seq OWNER TO themis;

--
-- Name: rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.rules_id_seq OWNED BY public.rules.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.schema_migrations (
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO themis;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.sessions (
    token text NOT NULL,
    user_id bigint NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO themis;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_id bigint
);


ALTER TABLE public.settings OWNER TO themis;

--
-- Name: statements; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.statements (
    id integer NOT NULL,
    filename text NOT NULL,
    period_start date,
    period_end date,
    opening_balance numeric(12,2),
    closing_balance numeric(12,2),
    parser text DEFAULT 'local'::text NOT NULL,
    validated boolean DEFAULT false NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    account_id bigint DEFAULT 1 NOT NULL,
    owner_id bigint
);


ALTER TABLE public.statements OWNER TO themis;

--
-- Name: statements_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.statements_id_seq OWNER TO themis;

--
-- Name: statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.statements_id_seq OWNED BY public.statements.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name text NOT NULL,
    owner_id bigint
);


ALTER TABLE public.tags OWNER TO themis;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tags_id_seq OWNER TO themis;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: taxes; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.taxes (
    id bigint NOT NULL,
    name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    due_date date NOT NULL,
    paid boolean DEFAULT false NOT NULL,
    owner_id bigint,
    CONSTRAINT taxes_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.taxes OWNER TO themis;

--
-- Name: taxes_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.taxes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.taxes_id_seq OWNER TO themis;

--
-- Name: taxes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.taxes_id_seq OWNED BY public.taxes.id;


--
-- Name: transaction_tags; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.transaction_tags (
    transaction_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.transaction_tags OWNER TO themis;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    statement_id integer,
    tx_date date NOT NULL,
    label text NOT NULL,
    amount numeric(12,2) NOT NULL,
    hash text NOT NULL,
    domain_id bigint,
    owner_id bigint
);


ALTER TABLE public.transactions OWNER TO themis;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO themis;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: themis
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'user'::text])))
);


ALTER TABLE public.users OWNER TO themis;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: themis
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO themis;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: themis
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: account_snapshots id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.account_snapshots ALTER COLUMN id SET DEFAULT nextval('public.account_snapshots_id_seq'::regclass);


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: analyses id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.analyses ALTER COLUMN id SET DEFAULT nextval('public.analyses_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: credits id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.credits ALTER COLUMN id SET DEFAULT nextval('public.credits_id_seq'::regclass);


--
-- Name: domains id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.domains ALTER COLUMN id SET DEFAULT nextval('public.domains_id_seq'::regclass);


--
-- Name: rules id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.rules ALTER COLUMN id SET DEFAULT nextval('public.rules_id_seq'::regclass);


--
-- Name: statements id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.statements ALTER COLUMN id SET DEFAULT nextval('public.statements_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: taxes id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.taxes ALTER COLUMN id SET DEFAULT nextval('public.taxes_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: account_snapshots; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.account_snapshots (id, account_id, snap_date, balance) FROM stdin;
1	2	2026-07-17	200.00
2	3	2026-07-17	2250.00
4	6	2026-07-17	700.00
5	4	2026-07-17	900.00
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.accounts (id, name, kind, interest_rate, deposit_limit, created_at, owner_id) FROM stdin;
1	Compte courant	courant	\N	\N	2026-07-17 07:32:19.167289+00	1
2	Livret A	livret_a	1.80	22500.00	2026-07-17 08:27:54.278323+00	1
3	PEL	pel	1.50	62000.00	2026-07-17 08:35:35.346043+00	1
4	Crypto	autre	2.00	\N	2026-07-17 08:38:50.751729+00	1
6	PEA	bourse	5.00	\N	2026-07-17 10:15:20.018195+00	1
7	Compte courant	courant	\N	\N	2026-07-17 10:21:01.509051+00	2
\.


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.analyses (id, month, content, created_at, owner_id) FROM stdin;
1	2026-06	### Vue d'ensemble\n\nLe mois de juin a été déficitaire avec un solde négatif de -162,58 €. Les dépenses ont largement dépassé les revenus, principalement en raison des transactions intercomptes et des frais familiaux.\n\n### Points d'attention\n\n- **Transactions Intercomptes** : 2850,00 € (contre une moyenne de 1000 € sur les trois mois précédents).\n- **Famille** : 2780,10 € (contre une moyenne de 346,37 € sur les trois mois précédents).\n\n### Actions concrètes\n\n1. **Réduire les transactions intercomptes** : Évitez les transferts non essentiels et regroupez les paiements pour réduire le nombre d'opérations à 500 €, soit une économie de 2350 €.\n2. **Gérer les dépenses familiales** : Identifiez les frais inutiles ou excessifs dans la catégorie Famille et limitez-la à 1000 € pour un mois normal.\n3. **Augmenter l'épargne** : Réalisez des économies sur les deux points précédents pour augmenter votre épargne de 250 €.\n\n### Tendance\n\nLes dépenses ont considérablement augmenté en juin, principalement à cause d'une forte augmentation dans la catégorie Famille et une opération importante de Transactions Intercomptes. Les mois précédents étaient beaucoup plus équilibrés avec des dépenses familiales faibles (22 € en mai) et aucune transaction intercompte significative.	2026-07-17 09:59:43.332746+00	1
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.budgets (id, monthly_limit, created_at, domain_id, owner_id) FROM stdin;
\.


--
-- Data for Name: credits; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.credits (id, name, monthly_amount, months_total, start_month, note, owner_id) FROM stdin;
1	truc	233.00	4	2026-07		1
\.


--
-- Data for Name: domains; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.domains (id, name, parent_id, color, owner_id) FROM stdin;
14	Transport	\N	#3F8F7B	\N
15	Alimentation	\N	#C77D2E	\N
16	Santé et Bien-être	\N	#D6455D	\N
17	Divertissement	\N	#8A5CD1	\N
18	Épargne et Investissements	\N	#2E8B57	\N
19	Vie Professionnelle	\N	#3D6B99	\N
21	Autres	\N	#8A8A99	\N
1	Logement	\N	#4C6FBF	\N
5	Famille	\N	#B5548A	\N
22	Logement	\N	#4C6FBF	1
23	Transport	\N	#3F8F7B	1
24	Alimentation	\N	#C77D2E	1
25	Santé et Bien-être	\N	#D6455D	1
26	Divertissement	\N	#8A5CD1	1
27	Épargne et Investissements	\N	#2E8B57	1
28	Vie Professionnelle	\N	#3D6B99	1
29	Famille	\N	#B5548A	1
30	Autres	\N	#8A8A99	1
31	Transactions Intercomptes	\N	#3D6B99	1
32	Logement	\N	#4C6FBF	2
33	Transport	\N	#3F8F7B	2
34	Alimentation	\N	#C77D2E	2
35	Santé et Bien-être	\N	#D6455D	2
36	Divertissement	\N	#8A5CD1	2
37	Épargne et Investissements	\N	#2E8B57	2
38	Vie Professionnelle	\N	#3D6B99	2
39	Famille	\N	#B5548A	2
40	Autres	\N	#8A8A99	2
\.


--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.rules (id, pattern, domain_id, owner_id) FROM stdin;
7	ENGIE	1	\N
8	EDF	1	\N
9	LOYER	1	\N
23	SALAIRE	19	\N
14	UBER EATS	17	\N
15	DELIVEROO	17	\N
16	MCDONALD	17	\N
17	ORANGE	17	\N
18	FREE MOBILE	17	\N
19	AMAZON PRIME	17	\N
20	SPOTIFY	17	\N
21	NETFLIX	17	\N
1	MONOPRIX	21	\N
2	INTERMARCHE	21	\N
3	LIDL	21	\N
4	AUCHAN	21	\N
5	LECLERC	21	\N
6	CARREFOUR	21	\N
10	re:\\yESSO\\y	21	\N
11	TOTALENERGIES	21	\N
12	UBER	21	\N
13	SNCF	21	\N
22	PHARMACIE	21	\N
24	VIREMENT	21	\N
25	FRAIS	21	\N
26	COTISATION	21	\N
27	CARREFOUR	24	1
28	LECLERC	24	1
29	AUCHAN	24	1
30	LIDL	24	1
31	INTERMARCHE	24	1
32	MONOPRIX	24	1
33	FRANPRIX	24	1
34	CASINO	24	1
35	LOYER	22	1
36	EDF	22	1
37	ENGIE	22	1
38	VEOLIA	22	1
39	SNCF	23	1
40	UBER	23	1
41	TOTALENERGIES	23	1
42	RATP	23	1
43	ESSENCE	23	1
44	NETFLIX	26	1
45	SPOTIFY	26	1
46	DISNEY	26	1
47	PHARMACIE	25	1
48	DOCTEUR	25	1
49	FRAIS BANCAIRES	30	1
50	COTISATION	30	1
51	MONTREUIL	28	1
52	ASSJAD	29	1
53	LES ULIS	24	1
54	LESSONSHARING	28	1
57	BOUYGUES	30	1
58	HAUTDEBIT	22	1
59	TARIK	29	1
60	CARREFOUR	34	2
61	LECLERC	34	2
62	AUCHAN	34	2
63	LIDL	34	2
64	INTERMARCHE	34	2
65	MONOPRIX	34	2
66	FRANPRIX	34	2
67	CASINO	34	2
68	LOYER	32	2
69	EDF	32	2
70	ENGIE	32	2
71	VEOLIA	32	2
72	SNCF	33	2
73	UBER	33	2
74	TOTALENERGIES	33	2
75	RATP	33	2
76	ESSENCE	33	2
77	NETFLIX	36	2
78	SPOTIFY	36	2
79	DISNEY	36	2
80	PHARMACIE	35	2
81	DOCTEUR	35	2
82	FRAIS BANCAIRES	40	2
83	COTISATION	40	2
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.schema_migrations (name, applied_at) FROM stdin;
001_init.sql	2026-07-17 07:32:19.140651+00
002_budgets.sql	2026-07-17 07:32:19.160703+00
003_settings.sql	2026-07-17 07:32:19.165144+00
004_features.sql	2026-07-17 07:32:19.167289+00
005_domains_seed.sql	2026-07-17 07:32:19.190367+00
006_domain_taxonomy.sql	2026-07-17 07:32:19.1914+00
007_domains_dedup.sql	2026-07-17 07:32:19.198652+00
008_categories.sql	2026-07-17 07:32:19.201543+00
009_rules_unique.sql	2026-07-17 07:32:19.203872+00
010_data_isolation.sql	2026-07-17 07:32:19.205412+00
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.sessions (token, user_id, expires_at) FROM stdin;
ug8v9Dryey-2k_48GA8_54_Fr3-6TjP9lDS_iio0KOE	1	2026-08-16 10:28:25.337843+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.settings (key, value, updated_at, owner_id) FROM stdin;
ai_config	{"provider": "ollama", "ollama_url": "http://192.168.100.44:11434", "ollama_model": "qwen2.5:14b", "anthropic_model": "claude-sonnet-4-6", "auto_categorize": true}	2026-07-17 09:50:15.142369+00	\N
\.


--
-- Data for Name: statements; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.statements (id, filename, period_start, period_end, opening_balance, closing_balance, parser, validated, uploaded_at, account_id, owner_id) FROM stdin;
2	Releve n006 du 22-06-2026-CCHQ 43609805111 M MADI TOUMANI.pdf	2026-05-21	2026-06-22	306.46	38.47	local	t	2026-07-17 07:36:23.054614+00	1	1
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.tags (id, name, owner_id) FROM stdin;
1	soeur	1
2	frigo	1
9	energie	1
10	enedis	1
12	taxes	1
13	urssaf	1
14	cotisations-mai	1
23	jes	1
27	remboursement	1
30	tiktok	1
22	telecom	1
34	bouygues	1
35	fast-food	1
36	coiffeur	1
45	starlink	1
6	compte-courant	1
48	visa	1
52	banque	1
26	paypal	1
19	voyage	1
42	credit	1
64	jess	1
25	cadeau	1
67	shein	1
38	courses	1
62	fête	1
63	amis	1
37	boucherie	1
3	deplacement	1
4	livret-a	1
74	loyer	1
77	demenagement	1
7	jessica	1
44	projet	1
82	etudes	1
85	internet	1
86	free	1
11	facture	1
21	abonnement	1
89	assurance	1
90	acheel	1
78	frere	1
79	pret	1
93	pel	1
94	salaire	1
95	salaire-juin	1
96	lessonsharing	1
\.


--
-- Data for Name: taxes; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.taxes (id, name, amount, due_date, paid, owner_id) FROM stdin;
1	machin	222.00	2026-08-28	f	1
\.


--
-- Data for Name: transaction_tags; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.transaction_tags (transaction_id, tag_id) FROM stdin;
79	1
79	2
75	3
75	6
69	7
40	7
77	9
77	10
77	11
60	12
60	13
60	14
78	12
78	13
78	14
76	7
76	19
71	26
71	27
72	7
72	25
72	30
73	11
73	21
73	22
73	34
58	35
65	36
70	37
70	38
68	26
68	19
68	7
68	42
67	7
67	44
67	45
66	3
66	6
63	48
63	7
63	19
64	21
64	52
62	26
62	19
62	7
62	42
59	7
59	25
59	67
61	38
61	62
61	63
61	37
56	3
56	4
56	74
55	7
55	44
55	77
54	78
54	79
53	7
53	44
53	82
52	11
52	21
52	85
52	86
45	11
45	21
45	89
45	90
44	78
44	79
43	93
50	94
50	95
50	96
51	94
51	95
51	96
49	94
49	95
49	96
48	94
48	95
48	96
47	94
47	95
47	96
46	94
46	95
46	96
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.transactions (id, statement_id, tx_date, label, amount, hash, domain_id, owner_id) FROM stdin;
39	2	2026-05-22	Prlv Idfm IDFM/002073317-4326232-2073281/MAND MANDATE-REFERENCE00000000000055687/7FR42277457385 Core	-20.00	b1bf035f7ccf25d81f4ce7e2bbb7725c64ef48d528daf97ad5da4ef58a527e9c	\N	1
41	2	2026-05-26	Carte X4519 Mp*carrefour Les Uli 23/05	-21.31	862bcdb2820dc1869dffff6925ffa6ad9a9c51f5b396329b8ba7dda7b9c11a6c	24	1
42	2	2026-05-29	Carte X4519 Mp*carrefour Les Uli 28/05	-19.00	36320f4a458e5cb09c466baf3708b5a84225e26e74e538107fa4d9d7d43835a6	24	1
60	2	2026-06-08	Carte X4519 URSSAF Idf Montreuil 05/06	-358.00	5689924b29524d95ab74ba17d342ffe75bc5ad6c8d28c6240f84f0fe648538c6	28	1
77	2	2026-06-17	Prlv Engie Mandat Core	-54.88	216ee2d4ee4a4d667c3064761a647b0c680345f868ad2eff31565f153567e017	22	1
78	2	2026-06-19	Carte X4519 URSSAF Idf Montreuil 18/06	-17.00	bcf514e2889f4e19917dc63e2de8b0d8be5b71abb2800b79dce11aa2d931ef56	28	1
79	2	2026-06-22	Carte X4519 Cofidis Amazon Ville 20/06	-63.68	f5fcfdbb5cf97ecf5af1830673a6c973d6159348ad10c0c33868658d1f22b69c	29	1
74	2	2026-06-14	Vir Inst vers Assjad Saida	-105.00	49065f520c12d399470cfd97dea31427c9d48662c6b8deef1b0a8ad4e91bc3eb	29	1
75	2	2026-06-15	De M. Madi Toumani Ben-moh	605.00	c08dce2048516d42d084f14b55e65c6e65c4ecb29ed2d7b64f7dcf8479f6dc4c	31	1
69	2	2026-06-10	Virement Vir Inst vers Ben-mohamed Madi T	-14.00	f6367cc71a5863274517d569ac92e53ab4264fcecc195c7c0b2f9eb09b388c1b	29	1
40	2	2026-05-23	Virement Vir Inst vers Ben-mohamed Madi T	-22.00	3eec624ce043df646a7a82edd5cdf1d7eb1006ecb67dbef83c699543265ad80f	29	1
76	2	2026-06-15	Virement Vir Inst vers Ben-mohamed Madi T	-605.00	e606650e849cea3b6ffee439ee5c43c40aba2be038b52d2d01e64dbd72f5ce37	29	1
72	2	2026-06-12	Carte X4519 Tiktok Shop Seller D 12/06	-12.38	cff73d34a39e074597deebf095e3ed9afdccafd1eeda3f64199c678a68d1dcd6	29	1
71	2	2026-06-12	Vir Inst de Paypal	197.79	9d3967e0dd229d9cf46629c23f485c27321e09a00c5cbc649c7972362876c3cc	31	1
70	2	2026-06-11	X4519 Les Uli 10/06	-39.46	f183b924f495a4bcb61f1290efe94b45d484350c20f97f6209594b94f8d82205	24	1
38	2	2026-05-22	Carte X4519 Burger King Les Ulis 21/05	-23.10	00fb7390e45003c329f9c24277160d23419b182955aad6ab613362e4552126a5	24	1
66	2	2026-06-10	De M. Madi Toumani Ben-moh	200.00	f9c833af81dbcf6a5d7d729d805cef36e6a29acbc4beec902de0d2263db6a9e0	31	1
58	2	2026-06-08	Carte X4519 Burger King Les Ulis 05/06	-12.00	0e6115b62df271058f121355a4557ff637e97c00a678999597738eb73619be9b	24	1
46	2	2026-06-05	Virement Lessonsharing 2026-06-04-MTBF:1-19-03-1	560.00	ae141762f5c8508fd1f5f11aad8c4d642bf28cc8b4e920f45adac9e3edca6307	28	1
64	2	2026-06-09	Prlv Offre Essentiel	-6.00	1713b5f2cc2c34ddf3128af25d9d0a957b4a7a7232af99e5bfa5ef1244f8bb1f	30	1
68	2	2026-06-10	Prlv Paypal (europe) $.a r.l. et Cie, 1050858593549 Paypal567J2253W2NHALU96ZZZ0000000000000000058 Core	-287.09	dd400ff021a7fda89d8e48f575986f2f48947b4cdd90cd19f079d43c383434d2	26	1
67	2	2026-06-10	Carte X4519 Amazon Payments Pari 08/06	-186.61	21729ff974875318fbec55a21b33df5784f33550a2f7c1c2c797bfada050c38c	29	1
63	2	2026-06-08	Virement Vir Inst vers Ambassade de Liber	-300.00	5be9872b869c10c00e6d8ee0802d5b944ecc6cc3d49be86342af902fa2c92970	26	1
62	2	2026-06-08	Prlv Paypal (europe) $.a r.l. et Cie, 1050779745906 Paypal567J2253W2NHALU96ZZZ0000000000000000058 Core	-391.89	1f0b39e26d4bc939f8a273d0a9435f26a7da419e1f1815a90c99544baeea5c0d	26	1
61	2	2026-06-08	X4519 Viandes Du 95 Argent 06/06	-7.50	82ae17ab488d668147c9f5a71a2c6eaa7dd4bdd670080b1c30ff0596deea926d	24	1
59	2	2026-06-08	Carte X4519 Shein Dublin 07/06	-39.43	5522969788a2ebb991c199040bab614650d245144b7da02f565090deaffcb08c	29	1
57	2	2026-06-06	Virement Vir Inst vers Aya N’goran	-45.00	ce70bb00bc6d888ed4a4a778b2b6a571fc3697ef402816ce2720b1ef69e18878	30	1
56	2	2026-06-05	Web M. Madi Toumani Ben-moha	-2850.00	a2d9fc28a764971e73db5eaa0a5ba7ab329fa9f666b62730639f283b79b8aa1d	31	1
55	2	2026-06-05	Vir Inst vers Ben-mohamed Madi T	-1100.00	cf256175c0d586ef4b4c6dba0013b5e1422acd096b2713bac6121e8f56949815	29	1
54	2	2026-06-05	Vir Inst vers M.madi Tarik	-300.00	5e0ab6c1e8e4641ca0285c8de9415d38e93dfaa32daed560c87875d26b2d2e44	29	1
53	2	2026-06-05	Vir Inst vers Ben-mohamed Madi T	-354.00	46d6b8376a1e3edfae974cd4d80646858a47c22bea9b0e89710ece6c27baf91c	29	1
73	2	2026-06-12	Prlv Bouygues Telecom 06xxxxx951BT1150PNIAM30 Core	-13.99	84a561d9edbc429a287ca123c1a5213c67c0b08830d0c032b313e66b36671221	30	1
52	2	2026-06-05	Prlv Free Telecom Free Hautdebit 147851605447939382 Core	-29.99	d2a231177c78374caf88094d211174d4f1756b94826d75d1ce3145e9a113c1bc	22	1
45	2	2026-06-04	Prlv Acheel France REF-996928EF59FA47A80BGFGWBH4 FR4527787F911 Core	-12.47	3ba6a9b63eb92b5bc1d8d0832321a5f701a9723785544c19327c0d564ceb4dce	22	1
44	2	2026-06-03	Virement Vir Inst de M. Madi Tarik	300.00	12c51872f348e194c4da397b1fcd41d6d3e018b1f6dc23a2784fdf9096551c9f	29	1
43	2	2026-06-01	Virement Mens.pel 44690429796 06/26	-50.00	3d68970445c11ef896dc560be7264be696ae059d59aa2b30fffe99c01251cf59	27	1
51	2	2026-06-05	Virement Lessonsharing 2026-06-04-MTB 00004F:1-07-04-1	1210.00	f6294c2114c8fe65343a699c4f22578c22d7c7feee99b83e06472293c67193ca	28	1
50	2	2026-06-05	Virement Lessonsharing 2026-06-04-MTB 00006F:1-24-04-1	840.00	ef213fef5ae6785a2384d5d9790e3f5a0c4ea484fb6ab326975c1196f3594d78	28	1
49	2	2026-06-05	Virement Lessonsharing 2026-06-04-MTB 00002F:1-23-03-1	840.00	482a9a0bd04cb297d681136d203bfc4c76108a23d3e4706ed43fd71180cfa04d	28	1
48	2	2026-06-05	Virement Lessonsharing 2026-06-04-MTB 00005F:1-17-04-1	1520.00	762c5be0493b8f4fb4c0d5a21ef95beb7425735eecdd9dd1231eb85239f887be	28	1
47	2	2026-06-05	Virement Lessonsharing 2026-06-04-MTB 00003F:1-26-03-1	840.00	33b68fda05ed7ed46ef671d4656513eeb987332a6a1a3068a6a951c7b63134b3	28	1
65	2	2026-06-09	Ret DAB X4519 Les Ulis 06/06 09H28	-20.00	6811c5838095a6de2184ce8f845aa68d852d8ba8522449e90d118f5b0fd9df45	25	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: themis
--

COPY public.users (id, username, password_hash, role, created_at) FROM stdin;
1	localadm	pbkdf2$sha256$210000$nx0zFmTghiqL3jC3zQ+KGQ$/+2acI+kGQhCjgJRo99JwhZcwRZ+P4rDj2nZECRkf08	admin	2026-07-17 07:32:49.369724+00
2	ben	pbkdf2$sha256$210000$zftxbIsSWo2H4PJ95d8ZOw$rAdCJBb46X6IDJztbRXatOo/uFIGgSZhDg6q05EKVLI	user	2026-07-17 10:21:01.507766+00
\.


--
-- Name: account_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.account_snapshots_id_seq', 5, true);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.accounts_id_seq', 7, true);


--
-- Name: analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.analyses_id_seq', 1, true);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: credits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.credits_id_seq', 1, true);


--
-- Name: domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.domains_id_seq', 40, true);


--
-- Name: rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.rules_id_seq', 83, true);


--
-- Name: statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.statements_id_seq', 3, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.tags_id_seq', 111, true);


--
-- Name: taxes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.taxes_id_seq', 1, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.transactions_id_seq', 116, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: themis
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: account_snapshots account_snapshots_account_id_snap_date_key; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.account_snapshots
    ADD CONSTRAINT account_snapshots_account_id_snap_date_key UNIQUE (account_id, snap_date);


--
-- Name: account_snapshots account_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.account_snapshots
    ADD CONSTRAINT account_snapshots_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_domain_unique; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_domain_unique UNIQUE (domain_id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: credits credits_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.credits
    ADD CONSTRAINT credits_pkey PRIMARY KEY (id);


--
-- Name: domains domains_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.domains
    ADD CONSTRAINT domains_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (name);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (token);


--
-- Name: statements statements_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.statements
    ADD CONSTRAINT statements_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: taxes taxes_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.taxes
    ADD CONSTRAINT taxes_pkey PRIMARY KEY (id);


--
-- Name: transaction_tags transaction_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transaction_tags
    ADD CONSTRAINT transaction_tags_pkey PRIMARY KEY (transaction_id, tag_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_accounts_owner; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_accounts_owner ON public.accounts USING btree (owner_id);


--
-- Name: idx_accounts_owner_name; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_accounts_owner_name ON public.accounts USING btree (owner_id, name);


--
-- Name: idx_analyses_owner_month; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_analyses_owner_month ON public.analyses USING btree (owner_id, month);


--
-- Name: idx_domains_owner; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_domains_owner ON public.domains USING btree (owner_id);


--
-- Name: idx_domains_owner_name_parent; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_domains_owner_name_parent ON public.domains USING btree (owner_id, name, COALESCE(parent_id, (0)::bigint));


--
-- Name: idx_domains_owner_root_name; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_domains_owner_root_name ON public.domains USING btree (owner_id, name) WHERE (parent_id IS NULL);


--
-- Name: idx_rules_owner; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_rules_owner ON public.rules USING btree (owner_id);


--
-- Name: idx_rules_owner_pattern_ci; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_rules_owner_pattern_ci ON public.rules USING btree (owner_id, lower(pattern));


--
-- Name: idx_sessions_expires; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_sessions_expires ON public.sessions USING btree (expires_at);


--
-- Name: idx_settings_owner_key; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_settings_owner_key ON public.settings USING btree (COALESCE(owner_id, (0)::bigint), key);


--
-- Name: idx_statements_owner; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_statements_owner ON public.statements USING btree (owner_id);


--
-- Name: idx_tags_owner; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_tags_owner ON public.tags USING btree (owner_id);


--
-- Name: idx_tags_owner_name; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_tags_owner_name ON public.tags USING btree (owner_id, name);


--
-- Name: idx_transactions_label; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_transactions_label ON public.transactions USING gin (to_tsvector('simple'::regconfig, label));


--
-- Name: idx_transactions_owner; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_transactions_owner ON public.transactions USING btree (owner_id);


--
-- Name: idx_transactions_owner_hash; Type: INDEX; Schema: public; Owner: themis
--

CREATE UNIQUE INDEX idx_transactions_owner_hash ON public.transactions USING btree (owner_id, hash);


--
-- Name: idx_tx_date; Type: INDEX; Schema: public; Owner: themis
--

CREATE INDEX idx_tx_date ON public.transactions USING btree (tx_date);


--
-- Name: account_snapshots account_snapshots_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.account_snapshots
    ADD CONSTRAINT account_snapshots_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- Name: accounts accounts_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: analyses analyses_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: budgets budgets_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.domains(id) ON DELETE CASCADE;


--
-- Name: budgets budgets_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: credits credits_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.credits
    ADD CONSTRAINT credits_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: domains domains_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.domains
    ADD CONSTRAINT domains_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: domains domains_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.domains
    ADD CONSTRAINT domains_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.domains(id) ON DELETE CASCADE;


--
-- Name: rules rules_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.domains(id) ON DELETE CASCADE;


--
-- Name: rules rules_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: settings settings_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: statements statements_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.statements
    ADD CONSTRAINT statements_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: statements statements_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.statements
    ADD CONSTRAINT statements_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tags tags_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: taxes taxes_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.taxes
    ADD CONSTRAINT taxes_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transaction_tags transaction_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transaction_tags
    ADD CONSTRAINT transaction_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: transaction_tags transaction_tags_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transaction_tags
    ADD CONSTRAINT transaction_tags_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.domains(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: themis
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.statements(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict vJRrUIqXhVpnfG0CDmbwyhcD5BcPclmQbEvaxIH0wtAPM7bSKKMv5h8kd6n3OPp

